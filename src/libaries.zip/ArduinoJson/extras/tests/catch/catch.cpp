// ArduinoJson - https://arduinojson.org
// Copyright Benoit Blanchon 2014-2021
// MIT License

#define CATCH_CONFIG_MAIN
#include "catch.hpp"
